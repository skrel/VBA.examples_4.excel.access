Extract all first into the your work folder. Do not open this file from Microsoft Outlook.

1) Fill the form in the middle; 
2) Check out your chooses by the pictures on the sides; 
3) Add notes if it is necessary; 
4) Click "PRINT" button before proceeding with the next assembly
